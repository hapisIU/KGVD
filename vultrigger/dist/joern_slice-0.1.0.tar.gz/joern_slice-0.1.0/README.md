# Joern Slice

This is the Joern Slice project.
