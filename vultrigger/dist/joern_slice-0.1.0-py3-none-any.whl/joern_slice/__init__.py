# joern_slice/__init__.py

from .cv_extract import extract_info

__all__ = ['extract_info']
